def count_in_list(lst, item):
    """Returns the number of times an item appears in a list."""
    return lst.count(item)
