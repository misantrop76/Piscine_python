from .count_in_list import count_in_list

count_in_list.__doc__
