# ft_package

A sample package for 42 project.

## Function: count_in_list

Returns the number of times an item appears in a list.
